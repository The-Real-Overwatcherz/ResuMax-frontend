// Background service worker for ResuMax LinkedIn Optimizer Extension
// Handles badge updates based on current tab

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    if (tab.url.includes('linkedin.com/in/')) {
      chrome.action.setBadgeText({ text: '✓', tabId })
      chrome.action.setBadgeBackgroundColor({ color: '#22c55e', tabId })
    } else {
      chrome.action.setBadgeText({ text: '', tabId })
    }
  }
})

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId)
    if (tab.url && tab.url.includes('linkedin.com/in/')) {
      chrome.action.setBadgeText({ text: '✓', tabId: activeInfo.tabId })
      chrome.action.setBadgeBackgroundColor({ color: '#22c55e', tabId: activeInfo.tabId })
    } else {
      chrome.action.setBadgeText({ text: '', tabId: activeInfo.tabId })
    }
  } catch {
    // Tab might not exist yet
  }
})
