// Content script that runs on LinkedIn profile pages
// Adds a floating "Analyze with ResuMax" button and loading overlay

(function() {
  // Don't add if already exists
  if (document.getElementById('resumax-fab')) return

  const fab = document.createElement('div')
  fab.id = 'resumax-fab'
  fab.innerHTML = `
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
    </svg>
    <span>Analyze</span>
  `

  fab.addEventListener('click', () => {
    const tooltip = document.createElement('div')
    tooltip.style.cssText = `
      position: fixed;
      bottom: 90px;
      right: 20px;
      background: #1a1a1a;
      color: white;
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 13px;
      z-index: 10001;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    `
    tooltip.textContent = '👆 Click the ResuMax icon in your toolbar'
    document.body.appendChild(tooltip)
    setTimeout(() => tooltip.remove(), 3000)
  })

  document.body.appendChild(fab)
})()

// ── Loading Overlay ──
const loadingMessages = [
  "🍜 Cooking your analysis...",
  "🔍 Scanning profile sections...",
  "📊 Crunching the numbers...",
  "✨ Polishing insights...",
  "🧠 AI is thinking hard...",
  "📝 Gathering experience data...",
  "🎓 Checking education...",
  "💼 Analyzing career path...",
  "🎯 Finding improvements...",
  "🚀 Almost there...",
]

let overlayElement = null
let messageInterval = null

function showLoadingOverlay() {
  // Remove any existing overlay first
  hideLoadingOverlay()
  
  overlayElement = document.createElement('div')
  overlayElement.id = 'resumax-loading-overlay'
  overlayElement.innerHTML = `
    <div class="resumax-overlay-content">
      <div class="resumax-spinner"></div>
      <div class="resumax-logo">RESUMAX</div>
      <div class="resumax-message">${loadingMessages[0]}</div>
      <div class="resumax-step">Capturing profile...</div>
      <div class="resumax-progress-container">
        <div class="resumax-progress-bar"></div>
      </div>
    </div>
  `
  
  // Add styles
  const styleEl = document.createElement('style')
  styleEl.id = 'resumax-overlay-styles'
  styleEl.textContent = `
    #resumax-loading-overlay {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 100%) !important;
      z-index: 2147483647 !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
    }
    .resumax-overlay-content {
      text-align: center;
      color: white;
    }
    .resumax-spinner {
      width: 70px;
      height: 70px;
      border: 4px solid rgba(74, 222, 128, 0.15);
      border-top-color: #4ade80;
      border-radius: 50%;
      animation: resumax-spin 0.8s linear infinite;
      margin: 0 auto 24px;
    }
    @keyframes resumax-spin {
      to { transform: rotate(360deg); }
    }
    .resumax-logo {
      font-size: 32px;
      font-weight: 800;
      letter-spacing: 6px;
      margin-bottom: 16px;
      background: linear-gradient(90deg, #4ade80, #22d3ee, #4ade80);
      background-size: 200% auto;
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      animation: resumax-gradient 2s linear infinite;
    }
    @keyframes resumax-gradient {
      to { background-position: 200% center; }
    }
    .resumax-message {
      font-size: 20px;
      color: #e4e4e7;
      margin-bottom: 8px;
      min-height: 32px;
    }
    .resumax-step {
      font-size: 14px;
      color: #71717a;
      margin-bottom: 24px;
    }
    .resumax-progress-container {
      width: 320px;
      height: 6px;
      background: rgba(255,255,255,0.1);
      border-radius: 3px;
      overflow: hidden;
      margin: 0 auto;
    }
    .resumax-progress-bar {
      height: 100%;
      width: 5%;
      background: linear-gradient(90deg, #4ade80, #22d3ee);
      border-radius: 3px;
      transition: width 0.3s ease;
    }
  `
  
  document.head.appendChild(styleEl)
  document.body.appendChild(overlayElement)
  document.body.style.overflow = 'hidden'
  
  // Rotate messages
  let msgIndex = 0
  messageInterval = setInterval(() => {
    msgIndex = (msgIndex + 1) % loadingMessages.length
    const msgEl = overlayElement?.querySelector('.resumax-message')
    if (msgEl) {
      msgEl.textContent = loadingMessages[msgIndex]
    }
  }, 1500)
  
  return true
}

function updateOverlayProgress(percent, step) {
  if (!overlayElement) return
  
  const bar = overlayElement.querySelector('.resumax-progress-bar')
  if (bar) {
    bar.style.width = `${percent}%`
  }
  
  const stepEl = overlayElement.querySelector('.resumax-step')
  if (stepEl && step) {
    stepEl.textContent = step
  }
}

function hideLoadingOverlay() {
  if (messageInterval) {
    clearInterval(messageInterval)
    messageInterval = null
  }
  const existing = document.getElementById('resumax-loading-overlay')
  if (existing) {
    existing.remove()
  }
  const style = document.getElementById('resumax-overlay-styles')
  if (style) {
    style.remove()
  }
  document.body.style.overflow = ''
  overlayElement = null
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'showOverlay') {
    const success = showLoadingOverlay()
    sendResponse({ success })
  }
  else if (request.action === 'updateProgress') {
    updateOverlayProgress(request.percent, request.step)
    sendResponse({ success: true })
  }
  else if (request.action === 'hideOverlay') {
    hideLoadingOverlay()
    sendResponse({ success: true })
  }
  else if (request.action === 'scrollTo') {
    window.scrollTo({ top: request.y, behavior: 'instant' })
    setTimeout(() => sendResponse({ success: true }), 150)
    return true
  }
  else if (request.action === 'getScrollInfo') {
    sendResponse({
      scrollHeight: document.documentElement.scrollHeight,
      viewportHeight: window.innerHeight,
      currentScroll: window.scrollY
    })
  }
  return true
})

