// ── Config ──
const SUPABASE_URL = 'https://jhugkndfphofckcszzds.supabase.co'
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpodWdrbmRmcGhvZmNrY3N6emRzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzUxOTExNDIsImV4cCI6MjA5MDc2NzE0Mn0.MUO1EXGCFWm3Wc6NrP4fHacPxUC2Auygj8TaKrv1S8w'
const API_URL = 'http://localhost:8000'

// ── Helpers ──
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms))

// ── DOM ──
const loginView = document.getElementById('login-view')
const mainView = document.getElementById('main-view')
const emailInput = document.getElementById('email')
const passwordInput = document.getElementById('password')
const loginBtn = document.getElementById('login-btn')
const loginError = document.getElementById('login-error')
const logoutBtn = document.getElementById('logout-btn')
const userName = document.getElementById('user-name')
const notLinkedin = document.getElementById('not-linkedin')
const readyView = document.getElementById('ready-view')
const analyzeBtn = document.getElementById('analyze-btn')
const analyzeText = document.getElementById('analyze-text')
const analyzeLoading = document.getElementById('analyze-loading')
const contextInput = document.getElementById('context-input')
const resultsView = document.getElementById('results-view')
const reanalyzeBtn = document.getElementById('reanalyze-btn')

// ── Auth ──
async function supabaseAuth(email, password) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'apikey': SUPABASE_ANON_KEY,
    },
    body: JSON.stringify({ email, password }),
  })
  if (!res.ok) {
    const err = await res.json()
    throw new Error(err.error_description || err.msg || 'Login failed')
  }
  return res.json()
}

async function refreshToken(refreshToken) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'apikey': SUPABASE_ANON_KEY,
    },
    body: JSON.stringify({ refresh_token: refreshToken }),
  })
  if (!res.ok) throw new Error('Token refresh failed')
  return res.json()
}

async function getValidToken() {
  const data = await chrome.storage.local.get(['access_token', 'refresh_token', 'token_expires_at'])
  if (!data.access_token) return null

  // Check if token is expired (with 60s buffer)
  const now = Math.floor(Date.now() / 1000)
  if (data.token_expires_at && now > data.token_expires_at - 60) {
    try {
      const result = await refreshToken(data.refresh_token)
      await chrome.storage.local.set({
        access_token: result.access_token,
        refresh_token: result.refresh_token,
        token_expires_at: now + result.expires_in,
      })
      return result.access_token
    } catch {
      await chrome.storage.local.clear()
      return null
    }
  }

  return data.access_token
}

// ── Init ──
document.addEventListener('DOMContentLoaded', async () => {
  const token = await getValidToken()
  const userData = await chrome.storage.local.get(['user_email', 'user_name'])

  if (token) {
    showMainView(userData.user_name || userData.user_email || 'User')
  } else {
    showLoginView()
  }
})

// ── Login ──
loginBtn.addEventListener('click', async () => {
  const email = emailInput.value.trim()
  const password = passwordInput.value

  if (!email || !password) {
    showError('Please enter email and password')
    return
  }

  loginBtn.disabled = true
  loginBtn.textContent = 'Signing in...'
  hideError()

  try {
    const result = await supabaseAuth(email, password)
    const now = Math.floor(Date.now() / 1000)

    await chrome.storage.local.set({
      access_token: result.access_token,
      refresh_token: result.refresh_token,
      token_expires_at: now + result.expires_in,
      user_email: result.user.email,
      user_name: result.user.user_metadata?.full_name || result.user.email.split('@')[0],
    })

    const name = result.user.user_metadata?.full_name || result.user.email.split('@')[0]
    showMainView(name)
  } catch (err) {
    showError(err.message)
  } finally {
    loginBtn.disabled = false
    loginBtn.textContent = 'Sign In'
  }
})

// Enter key to login
passwordInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') loginBtn.click()
})

// ── Logout ──
logoutBtn.addEventListener('click', async () => {
  await chrome.storage.local.clear()
  showLoginView()
})

// ── Analyze ──
analyzeBtn.addEventListener('click', async () => {
  const token = await getValidToken()
  if (!token) {
    showLoginView()
    return
  }

  // Show loading in popup
  analyzeText.classList.add('hidden')
  analyzeLoading.classList.remove('hidden')
  analyzeBtn.disabled = true

  let tab = null
  
  try {
    ;[tab] = await chrome.tabs.query({ active: true, currentWindow: true })

    // Capture single screenshot
    const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png', quality: 95 })
    
    // Convert to blob and send
    const response = await fetch(dataUrl)
    const blob = await response.blob()
    
    const formData = new FormData()
    formData.append('screenshot', blob, 'linkedin_profile.png')
    
    const ctx = contextInput.value.trim()
    if (ctx) formData.append('context', ctx)

    const res = await fetch(`${API_URL}/api/linkedin-optimizer/analyze`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    })

    if (!res.ok) throw new Error('Analysis failed')
    const data = await res.json()
    
    // Save report (fire and forget)
    setTimeout(async () => {
      try {
        const profileUrl = tab?.url || ''
        const profileName = data.profile_name || data.sections?.find(s => s.name === 'Headline')?.current || 'LinkedIn Profile'
        
        await fetch(`${API_URL}/api/reports/save`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
          body: JSON.stringify({
            report_type: 'linkedin',
            profile_identifier: profileUrl,
            profile_name: (profileName || '').substring(0, 100),
            overall_score: data.overall_score || 0,
            report_data: data,
          }),
        })
      } catch (e) {}
    }, 100)
    
    renderResults(data)
  } catch (err) {
    console.error('Analysis error:', err)
    alert('Analysis failed: ' + err.message)
  } finally {
    analyzeText.classList.remove('hidden')
    analyzeLoading.classList.add('hidden')
    analyzeBtn.disabled = false
  }
})

// ── Re-analyze ──
reanalyzeBtn.addEventListener('click', () => {
  resultsView.classList.add('hidden')
  readyView.classList.remove('hidden')
})

// ── View Helpers ──
function showLoginView() {
  loginView.classList.remove('hidden')
  mainView.classList.add('hidden')
}

function showMainView(name) {
  loginView.classList.add('hidden')
  mainView.classList.remove('hidden')
  userName.textContent = name
  resultsView.classList.add('hidden')

  // Check if on LinkedIn
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const url = tabs[0]?.url || ''
    if (url.includes('linkedin.com/in/')) {
      notLinkedin.classList.add('hidden')
      readyView.classList.remove('hidden')
    } else {
      notLinkedin.classList.remove('hidden')
      readyView.classList.add('hidden')
    }
  })
}

function showError(msg) {
  loginError.textContent = msg
  loginError.classList.remove('hidden')
}

function hideError() {
  loginError.classList.add('hidden')
}

// ── Render Results ──
function renderResults(data) {
  readyView.classList.add('hidden')
  resultsView.classList.remove('hidden')

  // Score
  const score = data.overall_score || 0
  const color = score >= 80 ? '#22c55e' : score >= 60 ? '#eab308' : '#ef4444'
  const circumference = 2 * Math.PI * 34
  const offset = circumference * (1 - score / 100)

  document.getElementById('score-circle').setAttribute('stroke', color)
  document.getElementById('score-circle').setAttribute('stroke-dashoffset', offset)
  document.getElementById('score-number').textContent = score
  document.getElementById('score-number').style.color = color
  document.getElementById('score-summary').textContent = data.overall_summary || ''

  // Sections
  const sectionsEl = document.getElementById('sections-list')
  sectionsEl.innerHTML = ''
  if (data.sections) {
    data.sections.forEach((s) => {
      const scoreClass = s.score >= 80 ? 'high' : s.score >= 60 ? 'mid' : 'low'
      const item = document.createElement('div')
      item.className = 'section-item'
      item.innerHTML = `
        <div class="section-header">
          <div class="section-name">
            <div class="dot ${s.status}"></div>
            ${esc(s.name)}
          </div>
          <span class="section-score ${scoreClass}">${s.score}/100</span>
        </div>
        <div class="section-details">
          <p class="section-current">${esc(s.current)}</p>
          ${s.suggestions.map(sg => `
            <div class="section-suggestion">
              <span class="arrow">→</span>
              <span>${esc(sg)}</span>
            </div>
          `).join('')}
        </div>
      `
      item.addEventListener('click', () => item.classList.toggle('open'))
      sectionsEl.appendChild(item)
    })
  }

  // Quick Wins
  const qwEl = document.getElementById('quick-wins')
  qwEl.innerHTML = ''
  if (data.quick_wins && data.quick_wins.length) {
    qwEl.innerHTML = `<div class="result-section-title">⚡ Quick Wins</div>`
    data.quick_wins.forEach((w, i) => {
      qwEl.innerHTML += `<div class="quick-win"><span class="num">${i + 1}</span><span>${esc(w)}</span></div>`
    })
  }

  // Headlines
  const hlEl = document.getElementById('headlines')
  hlEl.innerHTML = ''
  if (data.headline_suggestions && data.headline_suggestions.length) {
    hlEl.innerHTML = `<div class="result-section-title">Headline Suggestions</div>`
    data.headline_suggestions.forEach((h) => {
      hlEl.innerHTML += `
        <div class="headline-item">
          <span>${esc(h)}</span>
          <button class="copy-btn" data-copy="${esc(h)}">Copy</button>
        </div>
      `
    })
    // Add copy handlers
    hlEl.querySelectorAll('.copy-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation()
        navigator.clipboard.writeText(btn.dataset.copy)
        btn.textContent = '✓'
        setTimeout(() => btn.textContent = 'Copy', 1500)
      })
    })
  }

  // Keywords
  const kwEl = document.getElementById('keywords')
  kwEl.innerHTML = ''
  if (data.keyword_recommendations && data.keyword_recommendations.length) {
    kwEl.innerHTML = `<div class="result-section-title">Keywords to Use</div><div>`
    data.keyword_recommendations.forEach((kw) => {
      kwEl.innerHTML += `<span class="keyword-tag">${esc(kw)}</span>`
    })
    kwEl.innerHTML += `</div>`
    kwEl.querySelectorAll('.keyword-tag').forEach(tag => {
      tag.addEventListener('click', () => {
        navigator.clipboard.writeText(tag.textContent)
        tag.style.borderColor = '#22c55e'
        tag.style.color = '#22c55e'
        setTimeout(() => { tag.style.borderColor = ''; tag.style.color = '' }, 1000)
      })
    })
  }

  // Advanced Tips
  const tipEl = document.getElementById('advanced-tips')
  tipEl.innerHTML = ''
  if (data.advanced_tips && data.advanced_tips.length) {
    tipEl.innerHTML = `<div class="result-section-title">Advanced Tips</div>`
    data.advanced_tips.forEach((t) => {
      tipEl.innerHTML += `
        <div class="tip-card">
          <p class="tip-title">${esc(t.tip)}</p>
          <p class="tip-why">${esc(t.why)}</p>
          <div class="tip-how">
            <span class="arrow">→</span>
            <span>${esc(t.how)}</span>
          </div>
        </div>
      `
    })
  }
}

function esc(str) {
  const div = document.createElement('div')
  div.textContent = str || ''
  return div.innerHTML
}
